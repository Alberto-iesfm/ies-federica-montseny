package org.iesfm.socialNetwork.exceptions;

public class AuthorNotFoundException extends Exception{
}

package org.iesfm.socialNetwork.exceptions;

public class TagNotFoundException extends Exception{
}

package org.iesfm.socialNetwork.exceptions;

public class UserNotFoundException extends Exception{
}

package org.iesfm.zoo.exceptions;

public class FeedingNotFoundException extends Exception{
}

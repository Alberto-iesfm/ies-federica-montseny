package org.iesfm.zoo.exceptions;

public class CageNotExistsException extends Exception{
}
